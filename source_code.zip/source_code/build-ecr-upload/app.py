#!/usr/bin/env python3

from aws_cdk import core

from build_ecr_upload.build_ecr_upload_stack import BuildEcrUploadStack


app = core.App()
BuildEcrUploadStack(app, "build-ecr-upload")

app.synth()
