from aws_cdk import core
import aws_cdk.aws_codebuild as codebuild
import aws_cdk.aws_s3 as s3
import aws_cdk.aws_ecr as _ecr
import aws_cdk.aws_codecommit as codecommit

class BuildEcrUploadStack(core.Stack):

    def __init__(self, scope: core.Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # codebuild project meant to run in pipeline
        bucket = s3.Bucket(self, "MyArtifactbucket", bucket_name="vizi-artifact-bucket")
        ecr = _ecr.Repository(self, "MyArtifactECR", repository_name="vizi-artifact-ecr", removal_policy=core.RemovalPolicy.DESTROY)
        
        repository = codecommit.Repository(self, "vizi-repo", repository_name="vizi-code-repo")
        #codebuild.Project(self, "MyFirstCodeCommitProject", source=codebuild.Source.code_commit(repository=repository)

        codebuild.Project(self, "MyProject",
                source=codebuild.Source.code_commit(repository=repository),
                build_spec=codebuild.BuildSpec.from_object({
                "version": "0.2",
                "phases": {
                    "build": {
                        "commands": [
                            "echo \"Hello, CodeBuild!\"",
                            "python setup.py install",
                            "cd tests",
                            "python -m unittest -v test_simple.py",
                            "cd ..",
                            "echo Logging in to Amazon ECR...",
                            "$(aws ecr get-login --no-include-email --region $AWS_DEFAULT_REGION)",
                            "docker build -t ${tag}:latest .",
                            "docker tag $tag:latest $ecr:$tag",
                            "docker push $ecr",
                            "echo Build completed"
                            ]
                        }
                    }
            }),
                artifacts=codebuild.Artifacts.s3(
                bucket=bucket,
                include_build_id=False,
                package_zip=True,
                path="source/files",
                identifier="AddArtifact1"
            )
        )
 
        #Output Section
        core.CfnOutput(
            self, "ECRURI",
            description="ECR URI",
            value=ecr.repository_uri,
        )
        core.CfnOutput(
            self, "S3Bucket",
            description="S3 Bucket",
            value=bucket.bucket_name
        )

