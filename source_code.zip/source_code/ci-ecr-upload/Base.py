from aws_cdk import aws_codebuild, aws_ecr
from aws_cdk import aws_s3 as aws_s3
from aws_cdk import aws_ssm, core


class Base(core.Stack):
    def __init__(self, app: core.App, id: str, props, **kwargs) -> None:
        super().__init__(app, id, **kwargs)

        # pipeline requires versioned bucket
        bucket = aws_s3.Bucket(
            self, "SourceBucket",
            bucket_name=f"{props['namespace'].lower()}-{core.Aws.ACCOUNT_ID}",
            versioned=True,
            removal_policy=core.RemovalPolicy.DESTROY)
        
        # ssm parameter to get bucket name later
        bucket_param = aws_ssm.StringParameter(
            self, "ParameterB",
            parameter_name=f"{props['namespace']}-bucket",
            string_value=bucket.bucket_name,   #this is taking the value from bucket.bucket_name
            description='cdk pipeline bucket'
        )
        # ecr repo to push docker container into
        ecr = aws_ecr.Repository(
            self, "ECR",
            repository_name=f"{props['namespace']}",   #Repo name is simple the namespace value defined in props dict in app.py
            removal_policy=core.RemovalPolicy.DESTROY
        )

        # codebuild project meant to run in pipeline
        cb_docker_build = aws_codebuild.PipelineProject(
            self, "DockerBuild",
            project_name=f"{props['namespace']}-Docker-Build",
            build_spec=aws_codebuild.BuildSpec.from_source_filename(filename='build_spec/buildspec.yml'),
            environment=aws_codebuild.BuildEnvironment(privileged=True, build_image=aws_codebuild.LinuxBuildImage.STANDARD_2_0),
            # pass the ecr repo uri into the codebuild project so codebuild knows where to push
            environment_variables={
                #'build_image': aws_codebuild.LinuxBuildImage.STANDARD_2_0,
                'ecr': aws_codebuild.BuildEnvironmentVariable(value=ecr.repository_uri),
                'tag': aws_codebuild.BuildEnvironmentVariable(value='cdk')
            },
            description='Pipeline for CodeBuild',
            timeout=core.Duration.minutes(20),
        )
        # codebuild iam permissions to read write s3
        bucket.grant_read_write(cb_docker_build)

        # codebuild permissions to interact with ecr
        ecr.grant_pull_push(cb_docker_build)

        #Output Section
        core.CfnOutput(
            self, "ECRURI",
            description="ECR URI",
            value=ecr.repository_uri,
        )
        core.CfnOutput(
            self, "S3Bucket",
            description="S3 Bucket",
            value=bucket.bucket_name
        )

        self.output_props = props.copy() # copy() method copies props dict to output_props
        self.output_props['bucket']= bucket
        self.output_props['cb_docker_build'] = cb_docker_build

    # pass objects to another stack #
    # By using @property decorator, we can "reuse" the name of a property to avoid creating new names for the getters, setters, and deleters
    @property
    def outputs(self):
        return self.output_props
