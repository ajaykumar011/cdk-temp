from aws_cdk import core

from Base import Base  #importing Base Class from Base file
from Pipeline import Pipeline  #importing Pipeline Class from pipeline file

props = {'namespace': 'cdk-vizi-pipeline'}  #dictionary data-type creation - used later in base 
app = core.App()

# stack for ecr, bucket, codebuild
base = Base(app, f"{props['namespace']}-base", props)

# pipeline stack
pipeline = Pipeline(app, f"{props['namespace']}-pipeline", base.outputs)  #base.outputs are coming from @property decorator output
pipeline.add_dependency(base) #Pipeline depends on the base class

app.synth()
